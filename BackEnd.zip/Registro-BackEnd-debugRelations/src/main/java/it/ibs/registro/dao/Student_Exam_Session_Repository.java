package it.ibs.registro.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import it.ibs.registro.model.Student_Exam_Session;

@Repository
public interface Student_Exam_Session_Repository extends JpaRepository<Student_Exam_Session,Long> {

}
