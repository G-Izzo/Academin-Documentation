package it.ibs.registro;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RegistroApplicationTests {

	void contextLoads() {
	}

}
